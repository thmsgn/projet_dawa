/* ________________NAVBAR________________ */

const hamburger = document.querySelector(".hamburger");
const navMenu = document.querySelector(".nav-menu");

hamburger.addEventListener("click", mobileMenu);

function mobileMenu() {
    hamburger.classList.toggle("active");
    navMenu.classList.toggle("active");
}

var swiper = new Swiper(".mySwiper", {
    effect: "cube",
    grabCursor: true,
    cubeEffect: {
      shadow: true,
      slideShadows: true,
      shadowOffset: 20,
      shadowScale: 0.94,
    },
  });

// Transition sections selon scroll

$(document).scroll(function() {

  myID = document.getElementById("sec2-1");

  var myScrollFunc = function () {
      var y = window.scrollY;
      if (y >= 10) {
          myID.className = "section-2 show"
      } else {
          myID.className = "section-2 hide"
      }
  };

  window.addEventListener("scroll", myScrollFunc);
});

$(document).scroll(function() {

  myID2 = document.getElementById("sec2-2");

  var myScrollFunc2 = function () {
      var y = window.scrollY;
      if (y >= 10) {
          myID2.className = "sect2-text-right show"
      } else {
          myID2.className = "sect2-text-right hide"
      }
  };

  window.addEventListener("scroll", myScrollFunc2);
});

