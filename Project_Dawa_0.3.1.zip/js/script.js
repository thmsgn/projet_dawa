var map = L.map('map',{scrollWheelZoom:false}).setView([50.637220336097386, 3.062579409852214], 20);

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    }).addTo(map);

    var marker = L.marker([50.637220336097386, 3.062579409852214]).bindPopup("Centre de formation 1 <br/> <img src='assets/poptest.jpg' width='100px'/>").addTo(map);
 