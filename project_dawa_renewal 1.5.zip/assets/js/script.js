/* ________________NAVBAR________________ */

const hamburger = document.querySelector(".hamburger");
const navMenu = document.querySelector(".nav-menu");

hamburger.addEventListener("click", mobileMenu);

function mobileMenu() {
    hamburger.classList.toggle("active");
    navMenu.classList.toggle("active");
}

/* ________________SWIPER________________ */

var swiper = new Swiper(".mySwiper", {
    effect: "cube",
    grabCursor: true,
    cubeEffect: {
      shadow: true,
      slideShadows: true,
      shadowOffset: 20,
      shadowScale: 0.94,
    },
  });

/* ________________TRANS SCROLL________________ */


$(document).scroll(function() {

  myID = document.getElementById("sec2-1");

  var myScrollFunc = function () {
      var y = window.scrollY;
      if (y >= 10) {
          myID.className = "section-2 show"
      } else {
          myID.className = "section-2 hide"
      }
  };

  window.addEventListener("scroll", myScrollFunc);
});

$(document).scroll(function() {

  myID2 = document.getElementById("sec2-2");

  var myScrollFunc2 = function () {
      var y = window.scrollY;
      if (y >= 10) {
          myID2.className = "sect2-text-right show1"
      } else {
          myID2.className = "sect2-text-right hide1"
      }
  };

  window.addEventListener("scroll", myScrollFunc2);
});

$(document).scroll(function() {

  myID3 = document.getElementById("hr1");

  var myScrollFunc3 = function () {
      var y = window.scrollY;
      if (y >= 50) {
          myID3.className = "hr show2"
      } else {
          myID3.className = "hr hide"
      }
  };

  window.addEventListener("scroll", myScrollFunc3);
});

$(document).scroll(function() {

    myID4 = document.getElementById("sec3-1");
  
    var myScrollFunc4 = function () {
        var y = window.scrollY;
        if (y >= 1000) {
            myID4.className = "sect3-text-gauche show4"
        } else {
            myID4.className = "sect3-text-gauche hide3"
        }
    };
  
    window.addEventListener("scroll", myScrollFunc4);
  });

  $(document).scroll(function() {

    myID5 = document.getElementById("secavis");
  
    var myScrollFunc5 = function () {
        var y = window.scrollY;
        if (y >= 1700) {
            myID5.className = "review show5"
        } else {
            myID5.className = "review hide5"
        }
    };
  
    window.addEventListener("scroll", myScrollFunc5);
  });


  $(document).scroll(function() {

    myID6 = document.getElementById("sec4-1");
  
    var myScrollFunc6 = function () {
        var y = window.scrollY;
        if (y >= 1700) {
            myID6.className = "sect4-text-gauche show5"
        } else {
            myID6.className = "sect4-text-gauche hide5"
        }
    };

    window.addEventListener("scroll", myScrollFunc6);
  });

  $(document).scroll(function() {

    myID7 = document.getElementById("sec4-2");
  
    var myScrollFunc7 = function () {
        var y = window.scrollY;
        if (y >= 1700) {
            myID7.className = "sect4-text-droite show6"
        } else {
            myID7.className = "sect4-text-droite hide5"
        }
    };

    window.addEventListener("scroll", myScrollFunc7);
  });



$(window).scroll(function () {
    $('.map1').each(function () {
        var imagePos = $(this).offset().top;
        var imageHeight = $(this).height();
        var topOfWindow = $(window).scrollTop();

        if (imagePos < topOfWindow + imageHeight && imagePos + imageHeight > topOfWindow) {
            $(this).addClass("slideRight");
        } else {
            $(this).removeClass("slideRight");
        }
    });
});


/* ________________LEAFLET MAP________________ */

var map = L.map('map',{scrollWheelZoom:false}).setView([47.8998907579673, 2.6572366994171017], 5);

    L.tileLayer('https://tile.thunderforest.com/neighbourhood/{z}/{x}/{y}.png?apikey=a5a8d26a68e3433d98e25c3dcb63838f', {
    }).addTo(map);

    var marker = L.marker([48.031, -4.83758]).bindPopup("Centre de la Corbière, dans le phare. <br/> <img src='assets/pinmap2.png' width='100px'/>").addTo(map);
    var marker2 = L.marker([46.19053295385913, 2.0709351370214333]).bindPopup("Centre de Jarnages, sur le bord de la D990 <br/> <img src='assets/pinmap3.png' width='100px'/>").addTo(map);
    var marker3 = L.marker([44.39241991138394, 4.286937540448698]).bindPopup("Proche de tout, ce centre est une aubaine! (Attention aux sangliers)<br/> <img src='assets/pinmap4.png' width='100px'/>").addTo(map);
    var marker4 = L.marker([42.78449933784087, 0.15914065913191935]).bindPopup("Au sommet de la montagne, idéal pour apprendre!<br/> <img src='assets/pinmap5.png' width='100px'/>").addTo(map);


    

    